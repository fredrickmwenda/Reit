<div class="col-lg-5 list-half-map__right">
    <div class="gmz-mapbox"></div>
</div>