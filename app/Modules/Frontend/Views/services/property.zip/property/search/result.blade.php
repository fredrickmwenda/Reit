<div class="col-lg-7 list-half-map__left">
    <div class="list-apartment">
        <div class="list-apartment__content" data-plugin="nicescroll"></div>
    </div>
</div>