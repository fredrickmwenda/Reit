window.addEventListener("load", function(){
    var load_screen = document.getElementById("load_screen");
    if(load_screen !== null) {
        load_screen.classList.add("hide");
    }
});