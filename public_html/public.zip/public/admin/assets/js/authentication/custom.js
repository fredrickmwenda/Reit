(function($){
    'use strict';

    var GMZ_Action = {
        init: function(){
            this.formAuthAction();
        },

        formAuthAction: function(){

        }
    };

    GMZ_Action.init();
})(jQuery);