INSERT INTO `gmz_car_availability` (`id`, `post_id`, `check_in`, `check_out`, `number`, `price`, `booked`, `status`, `created_at`, `updated_at`) VALUES
(1, 7, 1611853200, 1611853200, '20', '', 0, 'unavailable', '2021-01-30 14:06:00', '2021-01-30 14:06:00'),
(2, 7, 1611939600, 1611939600, '20', '', 0, 'unavailable', '2021-01-30 14:06:12', '2021-01-30 14:06:12');