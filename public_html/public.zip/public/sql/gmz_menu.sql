INSERT INTO `gmz_menu` (`menu_id`, `menu_title`, `menu_position`, `created_at`, `updated_at`) VALUES
(1, 'Main menu', 'primary', '2021-01-25 06:52:50', '2021-05-29 02:40:43'),
(2, 'COMPANY', NULL, '2021-01-30 15:30:03', '2021-01-31 00:42:52'),
(3, 'SUPPORT', NULL, '2021-01-31 00:46:02', '2021-01-31 00:46:02'),
(4, 'TOP CITIES', NULL, '2021-01-31 00:47:56', '2021-01-31 00:47:56');