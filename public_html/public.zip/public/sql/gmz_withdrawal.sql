INSERT INTO `gmz_withdrawal` (`id`, `user_id`, `withdraw`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 100.00, 'peding', '2021-02-01 09:32:01', '2021-02-01 09:32:01'),
(2, 1, 150.00, 'peding', '2021-01-27 09:32:01', '2021-02-01 09:32:01'),
(3, 1, 1407.45, 'cancelled', '2021-02-01 10:00:40', '2021-02-01 10:08:04');