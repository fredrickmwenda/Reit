INSERT INTO `gmz_language` (`id`, `code`, `name`, `flag_code`, `flag_name`, `priority`, `rtl`, `status`, `created_at`, `updated_at`) VALUES
(1, 'en', 'English', 'gb', 'United Kingdom of Great Britain and Northern Ireland', 1, 'no', 'on', '2021-01-26 05:46:19', '2021-02-02 01:12:58'),
(2, 'vi', 'Vietnamese', 'vn', 'Viet Nam', 2, 'no', 'on', '2021-01-26 05:46:56', '2021-02-02 01:12:58');