INSERT INTO `gmz_earnings` (`id`, `user_id`, `total`, `balance`, `net_earnings`, `created_at`, `updated_at`) VALUES
(1, 1, 5682.60, 4261.95, 4261.95, '2021-02-01 09:22:46', '2021-03-25 07:32:24');