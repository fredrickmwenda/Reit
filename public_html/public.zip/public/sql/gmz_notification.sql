INSERT INTO `gmz_notification` (`id`, `user_from`, `user_to`, `title`, `message`, `type`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'New request booking for Car', 'New request booking for Car service on 2020-02-01', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(2, 1, 1, 'New request booking for Apartment', 'New request booking for Apartment service on 2020-02-01', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(3, 1, 1, 'New enquiry request for Car', 'New enquiry request for Car service on 2020-02-01', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(4, 1, 1, 'New enquiry request for Car', 'New enquiry request for Car service on 2020-02-02', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(5, 1, 1, 'New account has been created', 'New account has been created on 2020-02-01', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(6, 1, 1, 'New enquiry request for Car', 'New enquiry request for Car service on 2020-02-02', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(7, 1, 1, 'New enquiry request for Car', 'New enquiry request for Car service on 2020-02-02', 'system', '2021-02-01 06:42:03', '2021-02-01 06:42:03'),
(8, 1, 1, 'New Partner request', 'New Partner request on 02/02/2021', 'global', '2021-02-02 01:44:12', '2021-02-02 01:44:12'),
(9, 1, 4, 'Partner was approved', 'Your partner account has been approved on 02/02/2021', 'global', '2021-02-02 01:49:08', '2021-02-02 01:49:08');