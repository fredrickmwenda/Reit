<?php
/*
Plugin Name: Authorize.Net Gateway
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: Authorize.Net Payment Gateway for Vil Hive
Version: 1.1
*/
