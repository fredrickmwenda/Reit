<?php
/*
Plugin Name: PayU Gateway
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: PayU Payment Gateway for Vil Hive
Version: 1.0
*/
