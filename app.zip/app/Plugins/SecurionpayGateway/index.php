<?php
/*
Plugin Name: Securionpay Gateway
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: Securionpay Payment Gateway for Vil Hive
Version: 1.0
*/
