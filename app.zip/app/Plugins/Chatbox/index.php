<?php
/*
Plugin Name: Chatbox
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: Chatbox between Owner and Customer for Vil Hive
Version: 1.0
*/
