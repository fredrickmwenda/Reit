<?php
/*
Plugin Name: Invoice
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: Invoice for Vil Hive
Version: 1.0
*/
