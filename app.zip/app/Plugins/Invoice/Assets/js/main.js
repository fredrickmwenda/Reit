(function($){
    'use strict';

    var invoiceAction = {
        init: function(){

        }
    };
    invoiceAction.init();
})(jQuery);