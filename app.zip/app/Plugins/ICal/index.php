<?php
/*
Plugin Name: iCal Sync
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: Sync iCal calendar with Vil Hive
Version: 1.2
*/
