<?php
/*
Plugin Name: Braintree Gateway
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: Braintree Payment Gateway for Vil Hive
Version: 1.1
*/
