<?php

namespace GuzzleHttp6\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
