<?php
namespace GuzzleHttp6\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
