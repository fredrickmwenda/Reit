<?php
namespace GuzzleHttp6\Exception;

class TooManyRedirectsException extends RequestException
{
}
