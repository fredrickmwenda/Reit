<?php
/*
Plugin Name: BlueSnap Gateway
Plugin URI: https://booteam.co
Author: JreamOQ
Author URI: https://booteam.co
Description: BlueSnap Payment Gateway for Vil Hive
Version: 1.1
*/
