<div class="col-lg-7 list-half-map__left">
    <div class="list-beauty">
        <div class="list-beauty__content" data-plugin="nicescroll">
            <div class="gmz-load-more"></div>
        </div>
    </div>
</div>