<div class="gmz-loader @if(isset($page)) gmz-page-loader @endif">
    <div class="loader-inner">
        <div class="spinner-grow text-info align-self-center loader-lg"></div>
    </div>
</div>
