<?php
/**
 * Created by PhpStorm.
 * User: JreamOQ ( jreamoq@gmail.com )
 * Date: 11/25/20
 * Time: 17:34
 */

namespace App\Services;

abstract class AbstractService
{
    protected $repository;
}