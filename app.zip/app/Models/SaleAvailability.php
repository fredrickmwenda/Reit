<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SaleAvailability extends Model
{
    protected $table = 'property_availability';

    protected $guarded = [];

    
}

